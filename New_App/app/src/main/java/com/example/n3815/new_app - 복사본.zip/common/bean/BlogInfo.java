package com.example.n3815.new_app.common.bean;

/**
 * Created by N3815 on 2017-01-05.
 */

public class BlogInfo {

    public String item;
    public String title;
    public String link;
    public String description;
    public String bloggername;
    public String bloggerlink;
    public String postdate;

    public String getItem(){
        return this.item;
    }
    public void setItem(String item){
        this.item = item;
    }

}
