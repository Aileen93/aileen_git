package com.example.n3815.new_app.assembly;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.example.n3815.new_app.R;
import com.example.n3815.new_app.common.bean.AssemBean;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

/**
 * Created by N3815 on 2016-12-28.
 */

public class AssemblyListAdapter extends ArrayAdapter{
    // Adapter에 추가된 데이터를 저장하기 위한 ArrayList
    private ArrayList<AssemBean> assemblyItemList = new ArrayList<AssemBean>();
    private ArrayList<AssemBean> favoriteList = new ArrayList<AssemBean>();

    public interface ListBtnClickListener{
        void onListBtnClick(int position);
    }

    // 생성자로부터 전달된 resource id 값을 저장.
    int resourceId ;

    // 생성자로부터 전달된 ListBtnClickListener  저장.
    private AssemblyListActivity listBtnClickListener ;

    // 생성자
    AssemblyListAdapter(Context context, int resource, ArrayList<AssemBean> list, AssemblyListActivity clickListener) {
        super(context, resource, list) ;

        // resource id 값 복사. (super로 전달된 resource를 참조할 방법이 없음.)
        this.resourceId = resource ;
        this.listBtnClickListener = clickListener ;
    }


    // Adapter에 사용되는 데이터의 개수를 리턴. : 필수 구현
    @Override
    public int getCount() {
        return assemblyItemList.size() ;
    }

    // 지정한 위치(position)에 있는 데이터와 관계된 아이템(row)의 ID를 리턴. : 필수 구현
    @Override
    public long getItemId(int position) {
        return position ;
    }

    // 지정한 위치(position)에 있는 데이터 리턴 : 필수 구현
    @Override
    public Object getItem(int position) {
        return assemblyItemList.get(position) ;
    }

    // 데이터 정렬을 위한 Comparator
    public static Comparator<AssemBean> cmpAsc = new Comparator<AssemBean>() {
        @Override
        public int compare(AssemBean o1, AssemBean o2) {
            return o1.getEmpNm().compareTo(o2.getEmpNm()) ;
        }
    };

    /**
     * 어뎁터의 뷰를 구현하는 함수
     * @param position      -- 행의 index를 의미
     * @param convertView   -- 행 전체를 나타내는 뷰를 의미
     * @param parent         -- 어댑터를 가지고 있는 부모의 뷰를 의미
     * @return
     */
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        // viewHolder
        ViewHolder vh = new ViewHolder();
        final Context context = parent.getContext();
        View v=convertView;

        // getView에서 넘어오는 convertView는 이전에 그려졌던 view를 넘기는데요.
        // 한번도 inflate되지 않은 view라면 null로 전달되는 경우가 있으니 반드시 null체크는 해야합니다.
        if (v == null) {
            Log.e("Toggle Track:", "==================== 새로 그려지는 중입니다. ===========================");
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.activity_assem_item, parent, false);

            vh.toggleButton = (ToggleButton) v.findViewById(R.id.favorite);
            v.setTag(vh);
        }else{
            vh = (ViewHolder) v.getTag();
        }

        // Data Set(assemblyItemList)에서 position에 위치한 데이터 획득
        final AssemBean listViewItem = assemblyItemList.get(position);

        // 화면에 표시될 View(Layout이 inflate된)으로부터 위젯에 대한 데이터 획득
        ImageView imgView = (ImageView) v.findViewById(R.id.assem_empImg);
        TextView empNmView = (TextView) v.findViewById(R.id.assem_empNm);
        TextView origNmView = (TextView) v.findViewById(R.id.assem_origNm);
        final Button favorView = (Button) v.findViewById(R.id.favorite);

        // 각 위젯에 데이터 반영
        Picasso.with(context).load(listViewItem.getJpgLink()).into(imgView);
        empNmView.setText(listViewItem.getEmpNm());
        origNmView.setText(listViewItem.getOrigNm());

        // button1 클릭 시 TextView(textView1)의 내용 변경.
        final ToggleButton button1 = (ToggleButton) v.findViewById(R.id.favorite);
        button1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.v("=========================","=====================================★"+listViewItem.getEmpNm());
                /* 즐겨찾기 설정 */
                if (listViewItem.getFavorite() == false && isChecked){

                    listViewItem.setFavorite(true);
                    Log.v("즐겨찾기 추가","국회의원 이름 :: "+listViewItem.getEmpNm());
                    assemblyItemList.add(listViewItem);
                    Log.v("===============================","♥(등록)전체 대상자:"+assemblyItemList.size());
                    assemblyItemList.remove(position);

                    orderByAssemList(assemblyItemList);

                    Toast.makeText(context,"즐겨찾기가 등록 되었습니다.",Toast.LENGTH_LONG).show();

                /* 즐겨찾기 해제 */
                }else if(listViewItem.getFavorite() == true){

                    listViewItem.setFavorite(false);
                    assemblyItemList.add(listViewItem);
                    Log.v("===============================","♥(해제)전체 대상자:"+assemblyItemList.size());
                    assemblyItemList.remove(position);

                    orderByAssemList(assemblyItemList);

                    Toast.makeText(context,"즐겨찾기가 해제 되었습니다.",Toast.LENGTH_LONG).show();
                }

                // 데이터 변경분 알리기
                notifyDataSetChanged();
            }
        });

        button1.setBackgroundResource(R.drawable.imgbtn_defalut);
        if(listViewItem.getFavorite()){
            button1.setBackgroundResource(R.drawable.imgbtn_focused);
        }

        return v;
    }

    /**
     * 검색 기능
     * @param charText  -- 검색어
     * @param assemList -- 국회의원 리스트
     */
    public ArrayList<AssemBean> filter(String charText, ArrayList<AssemBean> assemList) {
        charText = charText.toLowerCase(Locale.getDefault());
        assemblyItemList.clear();   // 어뎁터 뷰에 연결된 배열 초기화

        // 검색 전, 검색된 ArrayList 초기화
        Log.v("＊＊＊＊＊＊＊＊＊","전체 대상자 :"+assemList.size()+", (검색어 :"+charText+")＊＊＊＊＊＊＊＊＊");

        if (charText.length() == 0) {
            Log.v("＊[확인]＊","검색어가 없으므로, 전체 대상자를 다시 넣어줍니다.");
            // 검색된 글자가 하나도 없을 경우, 전체 리스트를 넣어주기
            assemblyItemList.addAll(assemList);
        } else {
            // 검색된 글자가 있을 경우, 검색어와 일치하는 국회의원 정보를 담아주기
            for(AssemBean u : assemList){
                String name = u.getEmpNm();  // 국회의원 이름
                if (name.toLowerCase().contains(charText)) {
                    Log.v("＊[확인]＊","일치하는 국회의원 :"+name);
                    assemblyItemList.add(u);
                }
            }
        }

        orderByAssemList(assemblyItemList);

        // 데이터 변경분 알리기
        notifyDataSetChanged();

        return assemblyItemList;
    }

    /**
     * 대상 배열을 재정렬해줍니다.
     * @param targetArray
     */
    public ArrayList<AssemBean> orderByAssemList(ArrayList<AssemBean> targetArray){

        // 전체정렬
        Collections.sort(targetArray, cmpAsc);

        // 즐겨찾기 골라서 맨위로
        int i = targetArray.size();
        ArrayList<AssemBean> temp = new ArrayList<AssemBean>();
        for(int j = 0; j < targetArray.size(); j++){
            if(targetArray.get(j).getFavorite()){
                Log.v("====================",":::: 즐겨찾기 등록자 ::::"+targetArray.get(j).getEmpNm());

                temp.add(targetArray.get(j));
                targetArray.remove(j);
            }
        }
        Collections.sort(temp, cmpAsc);
        Log.v("====================",":::: 즐겨찾기 정렬완료 ::::");
        targetArray.addAll(0, temp);
        Log.v("====================",":::: 전체 정렬완료 ::::");

        return targetArray;
    }

    static class ViewHolder{
        ToggleButton toggleButton;
    }
}
